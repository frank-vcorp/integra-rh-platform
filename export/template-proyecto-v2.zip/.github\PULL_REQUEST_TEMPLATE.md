﻿Resumen
- Qué cambia y por qué.

Tareas PROYECTO.md Asociadas
- Copia/pega las líneas (con estado) de PROYECTO.md que cubre este PR.

Validaciones
- [ ] Checkpoints con nombre e ID correctos (CHK_YYYY-MM-DD_HHMM.md)
- [ ] Dossier actualizado si aplica (context/dossier_tecnico.md)

Notas
- Riesgos, migraciones, rollback.
