import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Dashboard from "./pages/Dashboard";
import Clientes from "./pages/Clientes";
import Puestos from "./pages/Puestos";
import Candidatos from "./pages/Candidatos";
import Procesos from "./pages/Procesos";
import Encuestadores from "./pages/Encuestadores";
import Pagos from "./pages/Pagos";
import CandidatoDetalle from "./pages/CandidatoDetalle";
import ClienteFormularioIntegrado from "./pages/ClienteFormularioIntegrado";
import CandidatoFormularioIntegrado from "./pages/CandidatoFormularioIntegrado";
import PuestoProcesoFlow from "./pages/PuestoProcesoFlow";
import Usuarios from "./pages/Usuarios";
import ClienteAcceso from "./pages/ClienteAcceso";
import ClienteDashboard from "./pages/ClienteDashboard";
import ClienteProcesoDetalle from "./pages/ClienteProcesoDetalle";
import ClienteCandidatoDetalle from "./pages/ClienteCandidatoDetalle";

function Router() {
  return (
    <Switch>
      {/* Rutas públicas para acceso de clientes mediante token */}
      <Route path="/cliente/:token" component={ClienteAcceso} />
      <Route path="/cliente/dashboard" component={ClienteDashboard} />
      <Route path="/cliente/proceso/:id" component={ClienteProcesoDetalle} />
      <Route path="/cliente/candidato/:id" component={ClienteCandidatoDetalle} />
      
      {/* Rutas protegidas con DashboardLayout */}
      <Route path="/">
        <DashboardLayout>
          <Route path="/" component={Dashboard} />
        </DashboardLayout>
      </Route>
      
      <Route path="/clientes">
        <DashboardLayout>
          <Route path="/clientes" component={Clientes} />
        </DashboardLayout>
      </Route>
      
      <Route path="/puestos">
        <DashboardLayout>
          <Route path="/puestos" component={Puestos} />
        </DashboardLayout>
      </Route>
      
      <Route path="/candidatos/:id">
        <DashboardLayout>
          <Route path="/candidatos/:id" component={CandidatoDetalle} />
        </DashboardLayout>
      </Route>
      
      <Route path="/candidatos">
        <DashboardLayout>
          <Route path="/candidatos" component={Candidatos} />
        </DashboardLayout>
      </Route>
      
      <Route path="/flujo-completo">
        <DashboardLayout>
          <Route path="/flujo-completo" component={ClienteFormularioIntegrado} />
        </DashboardLayout>
      </Route>
      
      <Route path="/flujo-candidato">
        <DashboardLayout>
          <Route path="/flujo-candidato" component={CandidatoFormularioIntegrado} />
        </DashboardLayout>
      </Route>
      
      <Route path="/flujo-puesto">
        <DashboardLayout>
          <Route path="/flujo-puesto" component={PuestoProcesoFlow} />
        </DashboardLayout>
      </Route>
      
      <Route path="/procesos">
        <DashboardLayout>
          <Route path="/procesos" component={Procesos} />
        </DashboardLayout>
      </Route>
      
      <Route path="/encuestadores">
        <DashboardLayout>
          <Route path="/encuestadores" component={Encuestadores} />
        </DashboardLayout>
      </Route>
      
      <Route path="/pagos">
        <DashboardLayout>
          <Route path="/pagos" component={Pagos} />
        </DashboardLayout>
      </Route>
      
      <Route path="/usuarios">
        <DashboardLayout>
          <Route path="/usuarios" component={Usuarios} />
        </DashboardLayout>
      </Route>
      
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
