# Manual de Usuario - Plataforma INTEGRA RH

¡Hola, Paula!

Este manual te guiará a través de los flujos de trabajo más comunes en tu nueva plataforma, usando ejemplos prácticos.

---

## Credenciales de Acceso (Temporales)

- **Usuario:** paula@vcorp.mx
- **Contraseña:** Paula2025@

---

## 1. Iniciar Sesión

Al abrir la aplicación, verás una pantalla de inicio de sesión. Ingresa tu correo y contraseña para acceder al dashboard principal.

---

## 2. Flujo de Trabajo 1: El Cliente Pide una Nueva Vacante

Este es el escenario más común: un cliente te pide que cubras un puesto.

**Ejemplo:** Tu cliente "Innovatech" necesita un "Desarrollador Frontend".

### Paso 1: Crea el Cliente (si no existe)
1.  Ve al panel **Clientes**.
2.  Haz clic en el botón `+`.
3.  Llena los datos de "Innovatech" y guarda.

### Paso 2: Crea el Puesto
1.  Ve al panel **Puestos**.
2.  Haz clic en el botón `+`.
3.  Escribe "Desarrollador Frontend" como nombre del puesto.
4.  En el menú desplegable, selecciona al cliente "Innovatech" y guarda.

### Paso 3: Registra un Candidato para ese Puesto
Encuentras a una candidata prometedora, "Ana Pérez".
1.  Ve al panel **Candidatos**.
2.  Haz clic en el botón `+`.
3.  Llena los datos de "Ana Pérez".
4.  **¡Paso Clave!** En el formulario, selecciona "Innovatech" en el menú "Cliente Asociado".
5.  El menú "Puesto al que Aplica" se activará. Selecciona "Desarrollador Frontend" y guarda.

¡Listo! Has registrado a Ana y la has vinculado directamente a la vacante correcta en un solo paso.

---

## 3. Flujo de Trabajo 2: Un Candidato "Walk-in"

Este escenario ocurre cuando un buen candidato llega por su cuenta y quieres guardarlo en tu base de datos para futuras oportunidades.

**Ejemplo:** "Carlos Gómez", un excelente Project Manager, te envía su CV.

### Paso 1: Registra al Candidato sin Puesto
1.  Ve al panel **Candidatos**.
2.  Haz clic en el botón `+`.
3.  Llena los datos de "Carlos Gómez". Puedes dejar los campos "Cliente Asociado" y "Puesto al que Aplica" vacíos. Guarda.

Carlos ya está en tu base de datos, disponible para cualquier oportunidad.

### Paso 2: Inicia un Proceso para él
Semanas después, "Innovatech" abre una vacante de "Project Manager".
1.  Ve al panel **Procesos**.
2.  Haz clic en el botón `+`.
3.  En el formulario, selecciona:
    - Cliente: "Innovatech"
    - Puesto: "Project Manager"
    - Candidato: "Carlos Gómez"
    - Tipo de Producto: "ILA" (o el que corresponda).
4.  Guarda el proceso.

¡Listo! Has vinculado a un candidato existente con una nueva oportunidad.

---

## 4. El Panel de Detalles: Tu Centro de Mando

Este panel a la derecha es dinámico y cambia según lo que selecciones en las listas.

### Si seleccionas un **Cliente**:
- Verás la información de contacto de la empresa.
- Verás listas de sus **Puestos Abiertos** y los **Candidatos Asociados** a ese cliente.

### Si seleccionas un **Candidato**:
- Verás su información de contacto.
- Tendrás acceso a varias secciones:
  - **Psicométricos:** Aquí puedes asignar nuevas pruebas o ver los resultados de las ya finalizadas.
  - **Procesos:** Verás en qué evaluaciones (ILA, ESE) está participando y podrás generar dictámenes.
  - **Historial Laboral:** Podrás ver y añadir registros de sus empleos anteriores.
  - **Documentos:** Podrás subir archivos (como su CV) y ver los que ya están en el sistema.

---

## 5. Funcionalidades Clave a Probar

### Edición de Datos
Junto a cada cliente, candidato, puesto o proceso, verás un icono de lápiz (✏️). Haz clic en él para editar la información en cualquier momento.

### Asignación de Psicométricos
Al seleccionar un candidato, ve a la sección "Psicométricos". Podrás:
1.  Hacer clic en **"Asignar Pruebas"** para abrir un formulario y elegir qué pruebas aplicar.
2.  Una vez finalizadas, podrás **ver los resultados detallados** y **descargar el reporte en PDF**.

### Carga de Documentos
Al seleccionar un candidato, ve a la sección "Documentos" para subir su CV, identificaciones, etc.

---

¡Esperamos tu feedback para seguir mejorando la herramienta!